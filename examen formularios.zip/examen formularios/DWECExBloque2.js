onload = function() {

//1
var info = document.getElementsByTagName('a')[0];

  info.onclick = function(e){
    e.preventDefault();
    document.getElementsByClassName('explicaHorario')[0].style.display = "block";

  }

//2

function imagenes(){
  var sec = document.getElementById("selector").selectedIndex;

  if(sec == 0){
    document.getElementsByTagName('img')[0].setAttribute("src", "salareuniones.png");
  }else if(sec == 1){
    document.getElementsByTagName('img')[0].setAttribute("src", "salaproyector.png");
  }else if(sec == 2 ){
    document.getElementsByTagName('img')[0].setAttribute("src", "salavideoconferencia.png");
  }else if(sec == 3 ){
    document.getElementsByTagName('img')[0].setAttribute("src", "salaordenadores.png");
  }
}

  onchange = imagenes;

if (window.localStorage != null) {
   obtenerClavesLocal();
   obtenerseccion();
}

var formulario = document.getElementById('formulario');

formulario.onsubmit = function(){

    var err = document.getElementsById('errores');
    var errList ="";
    var ret = true;




    // Email
    var email = document.getElementsByName("email")[0].value;

    if ( !/^\w+@\w+\.\w+$/.test(email) ){
      errList += "El email es incorrecto <br/>";
      ret = false;
    }

    // Departamento

    var depart = document.getElementsByName("depart")[0].value;
    var n = depart.split(" ");
    if ( n < 2){
      errList += "El departamento es incorrecto <br/>";
      ret = false;
    }

    // Nº asistentes

    var asis = document.getElementsByName("asistentes")[0].value;

    var v = /^\d{1-2}$/;

    if (v.test(asis) == false){
         errList += "Numero de asistentes erroneo<br/>"
         ret = false;
    }


    //aceptar condiciones
    if(cond.checked == false){
      errList += "Acepta las condiciones de liberar la sala en caso de cancelacion. <br/>";
      ret = false;
    }

    formulario.action = "DWECExResumenSala.html"

    //Cookie

    function setCookie(name,hora) {
      document.cookie = name+"="+hora;
      }

    if (ret){
      formulario.submit();
      guardarClavesLocal();

      var secc = document.getElementById("selector").selectedIndex;
      if(secc != 0){
          guardarseccion();
        }

      var name="hora";
      var hora=hora.value;
      setCookie(name,hora);

    }else{
      err.style.color="red";
    }

    err.innerHTML = errList;

  }

  function obtenerClavesLocal() {
        var email = localStorage.getItem("email");
        var email_object = document.getElementById("email");
        email_object.value = email;
        var fecha = localStorage.getItem("fecha");
        var fecha_object = document.getElementById("fecha");
        fecha_object.value = fecha;
        var hora = localStorage.getItem("hora");
        var hora_object = document.getElementById("hora");
        hora_object.value = hora;
  }

  function guardarClavesLocal() {
        var email_object = document.getElementById("email");
        var email = email_object.value;
        localStorage.setItem("email", email);
        var fecha_object = document.getElementById("fecha");
        var fecha = fecha_object.value;
        localStorage.setItem("fecha", fecha);
        var hora_object = document.getElementById("hora");
        var hora = hora_object.value;
        localStorage.setItem("hora", hora);
  }

  function obtenerseccion() {
        var seccion = localStorage.getItem("seccion");
        var seccion_object = document.getElementById("selector");
        seccion_object.value = seccion;
  }

  function guardarseccion() {
        var seccion_object = document.getElementById("selector");
        var seccion = seccion_object.value;
        localStorage.setItem("seccion", seccion);
  }




}
